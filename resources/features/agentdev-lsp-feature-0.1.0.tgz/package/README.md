# @agentdev/lsp-feature

lsp-feature feature for AgentDev.

## Installation

```bash
npm install @agentdev/lsp-feature
```

## Usage

```typescript
import { Agent } from 'agentdev';
import { LspFeature } from '@agentdev/lsp-feature';

const agent = new Agent().use(new LspFeature());
```

## Development

```bash
npm install
npm run build    # 或 npm run dev 监听模式
```

## License

MIT
